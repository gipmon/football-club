-- use p4g5;
use p4g5;

INSERT INTO football.team(name, max_age) VALUES ('Seniores Masculinos', 50);
INSERT INTO football.team(name, max_age) VALUES ('Seniores Femininos', 50);
