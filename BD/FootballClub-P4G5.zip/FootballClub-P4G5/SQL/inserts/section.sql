-- use p4g5;
use p4g5;


INSERT INTO football.section(type) VALUES ('Topo Norte');
INSERT INTO football.section(type) VALUES ('Central');