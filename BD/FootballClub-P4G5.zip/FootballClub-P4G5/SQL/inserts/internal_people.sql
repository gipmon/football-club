-- use p4g5;
use p4g5;

--Jogadores

INSERT INTO football.internal_people (bi, salary) VALUES (12345678, 50000);
INSERT INTO football.internal_people (bi, salary) VALUES (77777777, 10000);
INSERT INTO football.internal_people (bi, salary) VALUES (12445678, 0);
INSERT INTO football.internal_people (bi, salary) VALUES (39522123, 250);
INSERT INTO football.internal_people (bi, salary) VALUES (40128390, 50);
INSERT INTO football.internal_people (bi, salary) VALUES (52131283, 0);
INSERT INTO football.internal_people (bi, salary) VALUES (43123123, 0);
INSERT INTO football.internal_people (bi, salary) VALUES (12895726, 300);
INSERT INTO football.internal_people (bi, salary) VALUES (46728109, 0);
INSERT INTO football.internal_people (bi, salary) VALUES (90872134, 0);

--Treinadores

INSERT INTO football.internal_people (bi, salary) VALUES (16728392, 40000);
INSERT INTO football.internal_people (bi, salary) VALUES (49102019, 250);

--Staff

INSERT INTO football.internal_people (bi, salary) VALUES (13124523, 100);
INSERT INTO football.internal_people (bi, salary) VALUES (14563792, 1000);
INSERT INTO football.internal_people (bi, salary) VALUES (29675821, 1250);
INSERT INTO football.internal_people (bi, salary) VALUES (16758290, 30000);
INSERT INTO football.internal_people (bi, salary) VALUES (19283847, 850);
INSERT INTO football.internal_people (bi, salary) VALUES (39821392, 1500);
