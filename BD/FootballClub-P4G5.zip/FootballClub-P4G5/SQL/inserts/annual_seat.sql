-- use p4g5;
use p4g5;


INSERT INTO football.annual_seat (n_seat, row, id_section, start_date, duration, value, bi, season) VALUES (11, 'H', 2, '2014/09/02', 10, 95, 15672829, 2014);
