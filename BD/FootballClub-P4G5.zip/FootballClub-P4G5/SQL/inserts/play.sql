-- use p4g5;
use p4g5;

--Seniores Femininos

INSERT INTO football.play (bi, team_name) VALUES (52131283, 'Seniores Femininos');
INSERT INTO football.play (bi, team_name) VALUES (43123123, 'Seniores Femininos');
INSERT INTO football.play (bi, team_name) VALUES (90872134, 'Seniores Femininos');

--Seniores Masculinos

INSERT INTO football.play (bi, team_name) VALUES (12345678, 'Seniores Masculinos');
INSERT INTO football.play (bi, team_name) VALUES (77777777, 'Seniores Masculinos');
INSERT INTO football.play (bi, team_name) VALUES (12445678, 'Seniores Masculinos');
INSERT INTO football.play (bi, team_name) VALUES (39522123, 'Seniores Masculinos');
INSERT INTO football.play (bi, team_name) VALUES (40128390, 'Seniores Masculinos');
INSERT INTO football.play (bi, team_name) VALUES (12895726, 'Seniores Masculinos');
INSERT INTO football.play (bi, team_name) VALUES (46728109, 'Seniores Masculinos');