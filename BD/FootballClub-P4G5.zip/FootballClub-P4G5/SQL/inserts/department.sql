-- use p4g5;
use p4g5;

INSERT INTO football.department (address, name) VALUES ('Avenida do Dragao', 'Direccao');
INSERT INTO football.department (address, name) VALUES ('Rua do Estadio', 'Financeiro');
INSERT INTO football.department (address, name) VALUES ('Rua da Relva', 'Comercial');


