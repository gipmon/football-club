-- use p4g5;
use p4g5;


--Seniores Femininos

INSERT INTO football.player (bi, federation_id, weight, height) VALUES (52131283, 1234, 59, 160);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (43123123, 09382, 58, 170);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (90872134, 23234, 52, 162);

--Seniores Masculinos

INSERT INTO football.player(bi, federation_id, weight, height) VALUES (12345678, 201, 77, 189);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (77777777, 30012, 75, 182);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (12445678, 2001, 70, 177);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (39522123, 3482, 72, 175);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (40128390, 1859, 69, 167);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (12895726, 2394, 80, 192);
INSERT INTO football.player (bi, federation_id, weight, height) VALUES (46728109, 19283, 82, 184);



