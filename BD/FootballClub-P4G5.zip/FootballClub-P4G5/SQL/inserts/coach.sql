-- use p4g5;
use p4g5;

--Seniores Masculinos

INSERT INTO football.coach(bi, federation_id, role) VALUES (16728392, 132, 'Treinador');

--Seniores Femininos
INSERT INTO football.coach (bi, federation_id, role) VALUES (49102019, 245, 'Treinador');