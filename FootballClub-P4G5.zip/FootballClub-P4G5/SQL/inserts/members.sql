-- use p4g5;
use p4g5;


--Sem Lugar Anual

INSERT INTO football.members(bi, shares_in_day, shares_value) VALUES (26718293, 2014, 20);
INSERT INTO football.members (bi, shares_in_day, shares_value) VALUES (28372192, 2015, 30);

--Com Lugar Anual

INSERT INTO football.members (bi, shares_in_day, shares_value) VALUES (15672829, 2015, 50);
