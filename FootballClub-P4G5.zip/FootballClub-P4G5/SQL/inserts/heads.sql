-- use p4g5;
use p4g5;

--Seniores Masculinos

INSERT INTO football.heads(bi, team_name) VALUES (16728392, 'Seniores Masculinos');

--Seniores Femininos
INSERT INTO football.heads (bi, team_name) VALUES (49102019, 'Seniores Femininos');