-- use p4g5;
use p4g5;


--Direccao

INSERT INTO football.staff (bi, role, department_id) VALUES (16758290, 'Presidente', 1);
INSERT INTO football.staff (bi, role, department_id) VALUES (13124523, 'Vice-Presidente', 1);

--Departamento Financeiro

INSERT INTO football.staff (bi, role, department_id) VALUES (19283847, 'Director Financeiro', 2);
INSERT INTO football.staff (bi, role, department_id) VALUES (14563792, 'Gestor Financeiro', 2);

--Departamento Comercial

INSERT INTO football.staff (bi, role, department_id) VALUES (29675821, 'Director de Vendas', 3);
INSERT INTO football.staff (bi, role, department_id) VALUES (39821392, 'Vendedor', 3);

